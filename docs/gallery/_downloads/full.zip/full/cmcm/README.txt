CMCM v1.0
========
 * 
 * http://cmcm.io 
 *
 * Copyright 2014, Chris Malcolm
 * http://chris-malcolm.com/
 *
 * Licensed under the MIT license:
 * http://www.opensource.org/licenses/MIT
 *
========

Check out http://cmcm.io for more info

*To Install*
Drag this entire directory (cmcm/) to your server and point browser to http://yoursite.com/cmcm