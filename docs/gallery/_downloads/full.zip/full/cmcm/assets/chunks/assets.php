	<title>CMCM</title>
	<link rel="shortcut icon" href="img/CMCM.ico" type="image/x-icon" />
	
	<!-- Bootstrap css -->
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
	<!-- Jquery UI css -->
	<link href="assets/css/jquery-ui.css" rel="stylesheet">
	<link href="assets/css/jquery.filetree.css" rel="stylesheet">
	<!-- CMCM css -->
	<link href="assets/css/style.css" rel="stylesheet">
	
	
	<!-- Jquery -->
	<script type="text/javascript" src="assets/js/jquery-2.1.0.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery.mixitup.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery.filetree.js"></script>
	<script type="text/javascript" src="assets/js/jquery.resize.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery.placeholder.js"></script>
		<script type="text/javascript" src="assets/js/jquery.insertAtCaret.js"></script>
	<!-- Bootstrap js -->
	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
	<!-- Jquery UI custom -->
	<script type="text/javascript" src="assets/js/jquery-ui-1.10.4.sortable-autocomplete-tooltip-draggable.js"></script>
	<!--<script type="text/javascript" src="assets/js/jquery.dropdown.js"></script>-->
	<!-- Json utils -->
	<script type="text/javascript" src="assets/js/jsonUtils.js"></script>
	<!-- Time/date lib -->
	<script type="text/javascript" src="assets/js/moment.min.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap-datetimepicker.min.js"></script>
	<!-- Blueimp fileupload lib -->
	<script type="text/javascript" src="assets/js/blueimp/jquery.ui.widget.js"></script>
	<script type="text/javascript" src="assets/js/blueimp/jquery.iframe-transport.js"></script>
	<script type="text/javascript" src="assets/js/blueimp/jquery.fileupload.js"></script>
	<!-- Event source lib -->
	<script type="text/javascript" src="assets/js/eventsource.js"></script>
	<!-- CMCM js -->
	<script type="text/javascript" src="assets/js/cmcm.js"></script>
	<script type="text/javascript">cmcm.kelly = "<?=md5($_COOKIE['skey'])?>"</script>
	