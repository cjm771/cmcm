<div class='frunt-list'>
	{% for key, item in items %}
	<div class='frunt-list-item frunt-list-key-{{key}}'>{{ item }}</div>
	{% endfor %}
</div>